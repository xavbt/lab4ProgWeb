<?php
ob_start(); ?>
<h1>a</h1>
<div class="container">
  <?php
  include('includes/index-carousel.php');
  ?>
</div>
<div class="">
  <div class="container">
    <div class="row">
      <div class="col lg-6 sm-12">
        <h1>j'adore les méthodes de transportation de toutes sortes</h1>
        <p class="text-break">J'adore toute forme de véhicule. J'ai créé ce site dans le but de vous montrer la quantité incroyable de moyens de transportation qui existent actuellement sur le marché.
          C'est tout simplement incroyable! Les véhicules sont l'outil le plus utilisé par l'espèce humaine, mais ils sont rarement appréciés malgré leur utilité. Sur ce site, vous pourrez regarder tous les véhicules que je possède, ainsi qu'un moyen de me contacter directement pour parler de véhicules.
        </p>
      </div>
      <div class="col lg-6 sm-12">
        <img src="img-upload/vintage_cars.jpg" class="img-fluid" alt="mmm voiture">
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row">
      <?php
      include('includes/index-cards.php');
      ?>
    </div>
  </div>
  <div class="container-fluid py-5 text-center bg-dark text-white">
    <h1 class="display-5 fw-bold">J'ai aucune idée quoi écrire ici</h1>
    <p class="lead">According to all known laws of aviation, there is no way a bee should be able to fly.
Its wings are too small to get its fat little body off the ground.
The bee, of course, flies anyway because bees don't care what humans think is impossible.
Yellow, black. Yellow, black. Yellow, black. Yellow, black.
Ooh, black and yellow!
Let's shake it up a little.
Barry! Breakfast is ready!
Coming!
Hang on a second.
Hello?
Barry?
Adam?
Can you believe this is happening?
I can't.
I'll pick you up.
Looking sharp.
Use the stairs, Your father paid good money for those.
Sorry. I'm excited.
Here's the graduate.
We're very proud of you, son.</p>
  </div>


  <?php
  $region_content = ob_get_clean();

  require('includes/template.php');
  ?>