<!-- Insérer l'affichage des "cartes" (card) de catégorie ici -->
<?php
require_once(realpath('dal/DAL.php'));
$dal = new DAL();
$categories = $dal->CategoryFact()->getAllCategories();
if ($categories != null && sizeof($categories) >  0) {
    foreach($categories as $categorie) {
        $titre = $categorie->name;
        $description = $categorie->description;
        $image = $categorie->image;
        $id = $categorie->id;
        ?>

<div class="card col-lg-4 col-sm-6">
  <img src="img-upload/<?php echo $image?>" class="card-img-top">
  <div class="card-body">
    <h5 class="card-title"><?php echo $titre ?></h5>
    <p class="card-text"><?php echo $description ?></p>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal-<?php echo $id?>"> <i class="fas fa-info-circle"></i> En savoir plus</button>

    
    <div class="modal" id="exampleModal-<?php echo $id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5"><?php echo $titre ?></h1>
      </div>
      <div class="modal-body">
      <?php echo $description ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
      </div>
    </div>
  </div>
</div>
  </div>
</div>
<?php
    }
}
?>
</div>