<!-- Insérer votre pied de page ici -->

<footer class="text-center text-white" style="background-color: black;">   
    <div class="container-fluid">
    <div class="d-flex justify-content-center">
    <i class="fa-brands fa-facebook logo-icon" aria-hidden="true"></i>
    <i class="fa-brands fa-twitter logo-icon" aria-hidden="true"></i>
    <i class="fa-brands fa-square-google-plus logo-icon" aria-hidden="true"></i>
    <i class="fa-brands fa-github logo-icon" aria-hidden="true"></i>
    <i class="fa-brands fa-linkedin logo-icon" aria-hidden="true"></i>
    <i class="fa-brands fa-pinterest logo-icon" aria-hidden="true"></i>    
    </div>
    </div>
    <div class="row" style="background-color: grey;">
    <p>Xavier Boivin Thibeault © Tous droits réservés </p>
    </div>
      
</footer>