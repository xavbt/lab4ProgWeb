<?php
/*
Retourne la liste des produits d'une catégorie en format HTML : <table>.
Si la catégorie n'est pas spécifiée, utiliser la première catégorie (selon l'ordre croissant de nom).
*/
require_once(realpath('../dal/DAL.php'));

$dal = new DAL();

if (isset($_GET['categoryid'])) {
    $category_id = $_GET['categoryid'];
    $produits = $dal->ProductFact()->getAllproduits($category_id);

    if ($produits != null && sizeof($produits) > 0) {

        foreach ($produits as $produit) {
            $code = $produit->code;
            $titre = $produit->name;
            $id = $produit->id;
            $quantite = $produit->quantityInStock;
            $prix = number_format($produit->buyPrice, 2);

            echo "<tr>" .
                 "<td>" . $titre . "</td>" .
                 "<td>" . $code . "</td>" .
                 "<td>" . $quantite . "</td>" .
                 "<td>" . $prix . "$</td>" .
                 "</tr>";
        }
    } else {
        echo "Aucun produit trouvé.";
    }
} else {
    echo "La catégorie n'a pas été spécifiée.";
}