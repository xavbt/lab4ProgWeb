<?php
session_start();

ob_start();
?>
<div class="img-fluid text-center" style="max-width: 100%; height: auto;">
    <img src="img-upload/ships.jpg" alt="Description of the image" style="width:100%; max-height: 600px;">
</div>

<div class="d-flex justify-content-center">
    <div class="col-md-6 ps-5 text-center">
        <h1 class="mb-4">Nous joindre</h1>
        <form id="contactForm" name="contactForm" action="contactus-send.php">
            <div class="mb-3">
                <label for="nom" class="form-label">Votre nom</label>
                <input type="nom" class="form-control" id="nom" name="nom" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Adresse email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="message" class="form-label">Message</label>
                <textarea class="form-control" id="message" name="message" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>
</div>
</div>

<?php
$region_content = ob_get_clean();

require('includes/template.php');
?>