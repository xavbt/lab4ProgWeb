/*
Contient le code JavaScript/jQuery pour la récupération des produits d'une catégorie.
Appel AJAX au fichier ajax/get-products.php
*/
$(document).ready(function () {
  var categoryid = new URL(location.href).searchParams.get("categoryid");
  if ((categoryid == null)) {

    categoryid = $('.categoryBtn.active').data('categoryid');
    $('.categoryBtn[data-categoryid="' + categoryid + '"]').addClass('active');
    getImageSelonBouton(categoryid);
  }

 
  $(".btn-outline-primary").click(function () {
    $(".btn-outline-primary").removeClass("active");
    $(this).addClass("active");
    
    let categoryid = $(this).data('categoryid');

    getCategoryDetails(categoryid);
    loadProduits(categoryid);
  });

  
  function getCategoryDetails(categoryid) {
    var categoryImageSrc = 'img-upload/' + getImageSelonBouton(categoryid);
    $('#categoryImage').html('<img src="' + categoryImageSrc + '" class="img-fluid" alt="' + categoryImageSrc + '">');
  }

  function getImageSelonBouton(categoryid) {
    let categoryidImage;
    switch (Number(categoryid)) {
      case 7:
        categoryidImage = "trucks";
        break;
      case 5:
        categoryidImage = "motorcycles";
        break;
      case 2:
        categoryidImage = "ships";
        break;
      case 3:
        categoryidImage = "trains";
        break;
      case 1:
        categoryidImage = "vintage_cars";
        break;
      case 6:
        categoryidImage = "classic_cars";
        break;
    }
    return `${categoryidImage}.jpg`;
  }

  function loadProduits(categoryid) {
    $.ajax({
      url: 'ajax/get-products.php',
      type: 'GET',
      data: { categoryid: categoryid },
      success: function (response) {
        $('#productList').html(response);
      }
    });
  }
  
});
