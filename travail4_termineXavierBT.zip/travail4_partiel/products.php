<?php
ob_start();
require_once(realpath('dal/DAL.php'));

$dal = new DAL();
$categories = $dal->CategoryFact()->getAllCategories();
?>
<div class="img-fluid text-center" style="max-width: 100%; height: auto;">
  <img src="img-upload/ships.jpg" alt="Description of the image" style="width:100%; max-height: 600px;">
</div>

<div class="d-flex justify-content-center">
  <div class="container-fluid p-5">
    <div class="row">
      <div class="col-md-6 text-center">
        <h1>Nos produits classés par catégorie</h1>
        <div class="container-fluid">
          <div id="categoryImage"></div>
          <div class="btn-group btn-group-toggle d-flex flex-column justify-content-center" data-toggle="buttons">
            <?php 
            foreach ($categories as $category) { 
              ?>
              <a class='btn btn-outline-primary categoryBtn' data-categoryid="<?=$category->id?>"><?= $category->name ?></a>
            <?php
           } 
           ?>
          </div>
        </div>
      </div>
      <div class="col-md-6 ps-5">
        <h1 id="categorieNom"></h1>
        <table class="table">
          <thead>
            <tr>
              <th>Nom</th>
              <th>Produit</th>
              <th>Quantité</th>
              <th>Prix</th>
            </tr>
          </thead>
          <tbody id="productList"></tbody>
        </table>
      </div>
    </div>
  </div>
</div>


<?php
$region_content = ob_get_clean();
require('includes/template.php');

?>