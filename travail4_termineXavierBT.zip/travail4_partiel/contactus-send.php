<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$alertMessage = '';
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $name = $_GET['nom'];
    $email = $_GET['email'];
    $message = $_GET['message'];

    
        $mail = new PHPMailer(true);
        try {
            //Server settings
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      
            $mail->isSMTP();
            $mail->Host       = 'smtp.sendgrid.net';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'apikey';
            $mail->Password   = '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';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;
        
            //Recipients
            $mail->setFrom('pandre.savard@cchic.ca', 'Mailer');
            $mail->addAddress($email, $name);
        
            //Content
            $mail->isHTML(true);
            $mail->Subject = 'Inscription';
            $mail->Body    = $message;
        
        
            $mail->send();
            echo 'Message has been sent';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
        $alertMessage = '<div class="alert alert-success" role="alert">
                            Votre message a bien été envoyé
                        </div>';
        
        $_SESSION['alertMessage'] = $alertMessage;
        
        header("Location: contactus.php");
        exit();
    }