<?php

require_once(realpath(__DIR__ . '/base/FactoryBase.php'));
require_once(realpath(__DIR__ . '/../models/Category.php'));

class CategoryFactory extends FactoryBase
{
    public function getAllCategories()
    {
        $categories = array();

        $db = $this->dbConnect();
        $stmt = $db->prepare('SELECT * FROM tp4_categories ORDER BY Name');
        $stmt->execute();
        while ($row = $stmt->fetch()) {
            $categories[] = new Category($row);
        }
        $stmt->closeCursor();

        return $categories;
    }

    public function getCategory($id) {
        $Categorie = null;
        $db = $this->dbConnect();
        $sql = "SELECT * FROM tp4_categories WHERE Id = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute([$id]);

        if ($row = $stmt->fetch()) {
            $Produit = new Category($row);
        }
        $stmt->closeCursor();

        return $Categorie;
    }
}
