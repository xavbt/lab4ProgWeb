<?php

require_once(realpath(__DIR__ . '/base/FactoryBase.php'));
require_once(realpath(__DIR__ . '/../models/Product.php'));

class ProductFactory extends FactoryBase
{
    public function getAllproduits($categoryId)
    {
        $produits = array();

        $db = $this->dbConnect();
        $stmt = $db->prepare('SELECT * FROM tp4_products WHERE CategoryId = ?');
        $stmt->execute([$categoryId]);

        while ($row = $stmt->fetch()) {
            $produits[] = new Product($row);
        }

        $stmt->closeCursor();

        return $produits;
    }

}
